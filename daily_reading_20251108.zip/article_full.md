# Cities Under Heat: How Urban Design Can Keep Us Cool
（城市高温来袭：城市设计如何帮我们降温）

### 🕐 昨日复习提示
- **renewable** /rɪˈnuː.ə.bəl/ 可再生的
- **sustainability** /səˌsteɪ.nəˈbɪ.lə.ti/ 可持续性
- **transparency** /trænˈspær.ən.si/ 透明度

---

### Paragraph 1
In recent summers, many cities have recorded their hottest days on record. 
Concrete walls and asphalt roads store heat like a sponge, then release it at night. 
To fight this, planners are testing **sensors** /ˈsɛn.sɚz/ that map temperature street by street, 
so officials can send heat **alerts** /əˈlɜːrts/ to the most at‑risk neighborhoods and install shade where it matters most.

最近几个夏天，许多城市都记录到了史上最热的日子。混凝土墙和沥青路面像海绵一样储存热量，随后在夜间释放。为应对这一问题，规划者正在测试可以逐街绘制温度地图的**传感器**，这样政府就能向最危险的社区发布高温**预警**，并在最需要的地方增设遮阴设施。

### Paragraph 2
Scientists call this the **urban heat‑island** /ˈɜːrbən ˈhiːt ˌaɪ.lənd/ effect. 
Because dark surfaces absorb sunlight, two neighborhoods can feel very different even on the same day. 
A tree‑lined block with light‑colored roofs may feel **efficient** /ɪˈfɪʃ.ənt/ and walkable, 
while a dense block full of parking lots can trap heat like a bowl.

科学家把这种现象称为**城市热岛效应**。由于深色表面更易吸收阳光，即使在同一天，不同街区的体感也可能大相径庭。种满树、浅色屋顶的街区更**高效**、更适合步行，而停车场密集的街区就像一个碗一样困住热量。

### Paragraph 3
Simple design changes help. **Cool roofs** reflect sunlight; **permeable pavement** lets rain soak in; 
small parks between buildings improve airflow. At night, brighter but well‑aimed streetlight **brightness** /ˈbraɪt.nəs/ levels 
keep people safe without overheating sidewalks. None of these solutions is a magic **symbol** /ˈsɪm.bəl/ of progress, 
but together they make a difference.

简单的设计也能起作用。**冷屋顶**可反射阳光；**透水铺装**让雨水渗入地面；楼宇之间的小型公园改善空气流动。夜晚，**亮度**更高但方向更精准的路灯既能保证安全，又不会给人行道增温。这些做法都不是进步的魔法**符号**，但组合起来就能产生明显改变。

### Paragraph 4
Technology is only part of the story. Residents know the hottest bus stops and which apartments face direct sun all afternoon. 
City halls are learning to combine climate data with neighborhood meetings, so plans match daily life. 
When planners treat people as partners, cooling becomes faster, cheaper, and more fair.

技术只是故事的一部分。居民最清楚哪些公交站最热、哪些公寓整个下午都直面阳光。市政府开始把气候数据与社区会议结合起来，让方案贴近日常生活。当规划者把居民视为伙伴，降温就会更快、更省钱也更公平。

### Paragraph 5
Businesses are also adapting. Offices are testing flexible hours to avoid peak heat and setting up indoor “cool corners” with fans and plants. 
Delivery companies redesign routes to include more shade and water points. These **efficient** shifts protect workers’ health while keeping essential services running.

企业也在适应。办公室尝试弹性工作时间以避开高温时段，并设置带风扇与绿植的“清凉角”。快递公司重新规划路线，加入更多阴凉点和补水点。这些**高效**的调整既保护了员工健康，也保障了必要服务。

### Paragraph 6
In the long run, the coolest city is the one that grows more trees than excuses. 
Every newly planted tree is a tiny air‑conditioner; every green roof is a small shield against extreme weather. 
The future will still have hot days, but with smarter design—and steady community effort—we can keep our cities livable.

从长远看，最凉爽的城市不是借口最多的，而是种树最多的。每一棵新树都是一台微型空调；每一处绿色屋顶都是抵御极端天气的小小盾牌。未来依然会有酷热的日子，但依靠更聪明的设计与持续的社区努力，我们能让城市保持宜居。


---

## ✅ 重点词汇汇总（智能分级标注）

| 词汇 | 美式音标 | 中文释义 |
|------|-----------|-----------|
| **sensors** | /ˈsɛn.sɚz/ | 传感器 |
| **alerts** | /əˈlɜːrts/ | 预警；提醒 |
| **urban heat‑island** | /ˈɜːrbən ˈhiːt ˌaɪ.lənd/ | 城市热岛 |
| **efficient** | /ɪˈfɪʃ.ənt/ | 高效的 |
| **brightness** | /ˈbraɪt.nəs/ | 亮度 |
| **permeable pavement** | /ˈpɝː.mi.ə.bəl ˈpeɪv.mənt/ | 透水铺装 |
| **cool roof** | /kuːl ruːf/ | 冷屋顶 |
| **airflow** | /ˈer.floʊ/ | 气流 |