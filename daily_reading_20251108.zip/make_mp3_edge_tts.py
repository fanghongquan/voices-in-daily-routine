# pip install edge-tts
import asyncio
import edge_tts

TEXT_FILE = "article_en.txt"
OUTPUT = "city_heat_full.mp3"
VOICE = "en-US-AriaNeural"   # neutral American; try en-US-GuyNeural for male tone
RATE = "+0%"

async def main():
    with open(TEXT_FILE, "r", encoding="utf-8") as f:
        text = f.read()
    communicate = edge_tts.Communicate(text, voice=VOICE, rate=RATE)
    await communicate.save(OUTPUT)
    print(f"✅ Generated: {OUTPUT}")

if __name__ == "__main__":
    asyncio.run(main())
