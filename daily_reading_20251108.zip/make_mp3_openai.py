# pip install openai
from openai import OpenAI
import os

TEXT_FILE = "article_en.txt"
OUTPUT = "city_heat_full.mp3"
VOICE = "alloy"  # neutral American
MODEL = "gpt-4o-mini-tts"

def main():
    api_key = os.environ.get("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("Please set OPENAI_API_KEY environment variable.")
    client = OpenAI(api_key=api_key)
    with open(TEXT_FILE, "r", encoding="utf-8") as f:
        text = f.read()
    with client.audio.speech.with_streaming_response.create(
        model=MODEL,
        voice=VOICE,
        input=text
    ) as response:
        response.stream_to_file(OUTPUT)
    print(f"✅ Generated: {OUTPUT}")

if __name__ == "__main__":
    main()
