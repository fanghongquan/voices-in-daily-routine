# Daily Reading Package (2025-11-08)

This ZIP contains:
1) `article_full.md` — bilingual article with Chinese translation and bolded vocab.
2) `article_en.txt` — English-only text for TTS.
3) `article_en.ssml` — SSML version for higher quality TTS.
4) `make_mp3_edge_tts.py` — One-click script using Microsoft Edge TTS (requires internet).
5) `make_mp3_openai.py` — One-click script using OpenAI realistic-speech (requires API key).

## Quick Start

### Option A: Edge TTS (no API key)
```bash
pip install edge-tts
python make_mp3_edge_tts.py
# Output: city_heat_full.mp3
```

### Option B: OpenAI realistic-speech
```bash
pip install openai
# set env var: export OPENAI_API_KEY=your_key
python make_mp3_openai.py
# Output: city_heat_full.mp3
```

Upload/play the MP3 anywhere (GitHub/COS/OSS) or play locally on your phone.
